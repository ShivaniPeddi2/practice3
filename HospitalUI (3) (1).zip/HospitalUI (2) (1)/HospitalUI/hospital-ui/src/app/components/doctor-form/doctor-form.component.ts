import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Doctor } from '../../models/doctor';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
@Component({
  selector: 'app-doctor-form',
  standalone:true,
  imports: [CommonModule,FormsModule,MatFormFieldModule,MatInputModule,MatButtonModule],
  templateUrl: './doctor-form.component.html',
  styleUrl: './doctor-form.component.scss'
})
export class DoctorFormComponent {
    @Input() doctor: Doctor = { doctorId: 0, name: '', specialty: '' };
  @Output() formSubmit = new EventEmitter<Doctor>();
  @Output() cancel = new EventEmitter<void>();

  submitForm() {
    this.formSubmit.emit(this.doctor);
  }

  cancelForm() {
    this.cancel.emit();
  }

}
