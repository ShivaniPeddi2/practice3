import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Doctor } from '../../models/doctor';
import { DoctorService } from '../../Services/doctor.service';
import {MatTableModule} from '@angular/material/table';
import {MatButtonModule, MatIconButton} from '@angular/material/button';
import{MatIconModule} from '@angular/material/icon';
import { DoctorFormComponent } from '../doctor-form/doctor-form.component';
@Component({
  selector: 'app-doctor-list',
  standalone: true,
  imports: [CommonModule,MatTableModule,MatButtonModule,MatIconModule,DoctorFormComponent],
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.scss']
})
export class DoctorListComponent implements OnInit {
  doctors: Doctor[] = [];
  displayedColumns:string[]=['doctorId','name','specialty','actions'];
  selectedDoctor:Doctor|null=null;
  isFormVisible=false;

  constructor(private doctorService: DoctorService) {}

  ngOnInit(): void {
   
    this.loadDoctors();
    
  }
  loadDoctors():void{
    this.doctorService.getDoctors().subscribe({
      next:(data)=>
      {
        this.doctors=data;
      },
        error:(err)=>console.error("Error loading doctors",err)
      });
  }
  
  deleteDoctor(doctorId:number):void{
    
    this.doctorService.deleteDoctor(doctorId).subscribe({
      next:()=>{
        this.doctors=this.doctors.filter(d=>d.doctorId !== doctorId);
    },
    error:(err)=>console.error("Error deleteing doctor",err),
    });
  }
  updateDoctor(doctor:Doctor):void{
   this.selectedDoctor={...doctor};
   this.isFormVisible=true;
  }
  createDoctor():void{
    this.selectedDoctor={doctorId:0,name:'',specialty:''};
    this.isFormVisible=true;
  }
  handleFormSubmit(doctor:Doctor):void
  {
    if(doctor.doctorId==0){
     this.doctorService.createDoctor(doctor).subscribe({
      next:(newId)=>{
        doctor.doctorId=newId;
        this.doctors=[...this.doctors,doctor];
        this.isFormVisible=false;

      },
      error:(err)=>console.error('Error creating doctor',err),
     });
  }else {
    this.doctorService.updateDoctor(doctor).subscribe({
      next:()=>{
        // const index=this.doctors.findIndex((d)=>d.doctorId===doctor.doctorId);
        // if(index!== -1)
        // {
        //   this.doctors[index]=doctor;
        // }
         this.doctors = this.doctors.map(d =>
          d.doctorId === doctor.doctorId ? doctor : d
        );
        this.isFormVisible=false;

      },
      error:(err)=>console.error('Error updating dotor',err),
    });
  }
  }
  cancelForm():void{
    this.isFormVisible=false;
    this.selectedDoctor=null;
  }
  
}
