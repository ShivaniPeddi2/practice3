import { Routes } from '@angular/router';
import { DoctorListComponent } from './components/doctor-list/doctor-list.component';

export const routes: Routes = [
    {
    path: '',
    component: DoctorListComponent
  }
];
