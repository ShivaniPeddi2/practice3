export interface Doctor {
  doctorId: number;
  name: string;
  specialty: string;
}
