import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 import { Doctor } from '../models/doctor';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private apiUrl = 'http://localhost:5028/api/doctors'; 
  constructor(private http: HttpClient) {}

  getDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(this.apiUrl);
  }
  deleteDoctor(doctorId:number):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/${doctorId}`);
  }
  updateDoctor(doctor:Doctor):Observable<void>{
    return this.http.put<void>(`${this.apiUrl}/${doctor.doctorId}`,doctor);
  }
  createDoctor(doctor:Doctor):Observable<number>{
    return this.http.post<number>(this.apiUrl,doctor);
  }

}
