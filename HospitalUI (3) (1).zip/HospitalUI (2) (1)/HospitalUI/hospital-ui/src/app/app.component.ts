import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DoctorListComponent } from './components/doctor-list/doctor-list.component';

@Component({
  selector: 'app-root',
  imports: [DoctorListComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'hospital-ui';
}
